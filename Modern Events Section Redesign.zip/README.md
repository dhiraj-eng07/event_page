
  # Modern Events Section Redesign

  This is a code bundle for Modern Events Section Redesign. The original project is available at https://www.figma.com/design/2ZEdQyHz3yAVdLlwjOLY0b/Modern-Events-Section-Redesign.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  